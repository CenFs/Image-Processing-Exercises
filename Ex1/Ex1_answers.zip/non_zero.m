function num = non_zero(S)
num = length(find(S==1));
end